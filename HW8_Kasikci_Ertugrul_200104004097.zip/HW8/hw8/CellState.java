package hw8;

/**
 * Cell types 
 * @author ekasi
 */
public enum CellState {
    E, P, A
}
